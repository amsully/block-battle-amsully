// Copyright 2015 theaigames.com (developers@theaigames.com)

//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at

//        http://www.apache.org/licenses/LICENSE-2.0

//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
//	
//    For the full copyright and license information, please view the LICENSE
//    file that was distributed with this source code.

package bot;

import java.awt.Point;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import field.Field;
import field.Shape;
import field.ShapeType;
import moves.MoveType;

/**
 * BotStarter class
 * 
 * This class is where the main logic should be. Implement getMoves() to return
 * something better than random moves.
 * 
 * @author Jim van Eeden <jim@starapple.nl>
 */

public class BotStarter {

        static int numberOfRotations;

        public BotStarter() {
        }

        /**
         * Returns a random amount of random moves
         * 
         * @param state
         *                : current state of the bot
         * @param timeout
         *                : time to respond
         * @return : a list of moves to execute
         */
        public ArrayList<MoveType> getMoves(BotState state, long timeout) {

                ArrayList<MoveType> moves = new ArrayList<MoveType>();

                Field currField = (state.getMyField());
                ShapeType currShapeType = state.getCurrentShape();
                Point currShapeLocation = state.getShapeLocation();
                Shape currShape = new Shape(currShapeType, currField, currShapeLocation);

                numberOfRotations = (currShapeType == ShapeType.I) ? 2 : (currShapeType == ShapeType.O) ? 1 : 4;

                Double max_height = currField.getMaxHeight();

                int board_max = 20;
                for (int i = max_height.intValue() + 1; i < board_max; i++) {
                        moves.add(MoveType.DOWN);
                        currShape.oneDown();
                }

//                Result results = searchSpace(currShape, currField, moves, ""); // Search
                                                                               // all
                                                                               // initial
                
                Result results = null;
                for(int i = 0; i < numberOfRotations; i++){
                        if(i != 0){
                                currShape.turnRight();
                                moves.add(MoveType.TURNRIGHT);
                        }
                        Result temp = searchSpace(currShape, currField, moves, "");
                        
                        if(results == null || temp.score > results.score)
                                results = temp;
                }
                
//                write(state.getRound() + " FINAL DECISION: " + results.score + " MOVES: " + results.moves.toString());

                if (results.moves.isEmpty()) {
                        results.moves.add(MoveType.DOWN);
                }
                return results.moves;

        }

        private Result searchSpace(Shape currShape, Field field, ArrayList<MoveType> moves, String prev) {

                double locationScore = field.evaluateScore(currShape);
//                write("DECISION: " + locationScore + " MOVES: " + moves.toString());
                // write("DECISION: " + locationScore);
                Result spaceResult = new Result(moves, locationScore);
                if (locationScore == -Double.MAX_VALUE) {
                        return spaceResult;
                }

//                if (!prev.equals("Rotate") && !prev.equals("Drop")) {
//                if(!prev.isEmpty()){
//                        for (int i = 0; i < numberOfRotations; i++) {
//                                if (i != 0) {
//                                        ArrayList<MoveType> temp = new ArrayList<MoveType>(moves);
//                                        temp.add(MoveType.TURNRIGHT);
//                                }
//
//                                currShape.turnRight();
//                                Result tempResult = searchSpace(currShape, field, moves, "Rotate");
//
//                                if (tempResult.score > spaceResult.score) {
//                                        spaceResult = tempResult;
//                                }
//                        }
//                        currShape.turnRight();
//                }

                if (!prev.equals("Left") && !prev.equals("Rotate")) {
                        spaceResult = checkRight(spaceResult, (currShape), field, new ArrayList<MoveType>(moves));
                }

                if (!prev.equals("Right") && !prev.equals("Rotate")) {
                        spaceResult = checkLeft(spaceResult, (currShape), field, new ArrayList<MoveType>(moves));
                }

                spaceResult = checkDown(spaceResult, (currShape), field, new ArrayList<MoveType>(moves));

                return spaceResult;
        }

        private Result checkDown(Result spaceResult, Shape shape, Field currField, ArrayList<MoveType> moves) {
                // TODO Auto-generated method stub
                moves.add(MoveType.DOWN);
                shape.oneDown();

                Result tempResult = searchSpace(shape, currField, moves, "Drop");

                if (tempResult.score > spaceResult.score) {
                        spaceResult = tempResult;
                }

                shape.oneUp();
                return spaceResult;
        }

        private Result checkLeft(Result spaceResult, Shape tempShape, Field currField, ArrayList<MoveType> moves) {
                // TODO Auto-generated method stub
                moves.add(MoveType.LEFT);
                tempShape.oneLeft();

                Result tempResult = searchSpace(tempShape, currField, moves, "Left");

                if (tempResult.score > spaceResult.score) {
                        spaceResult = tempResult;
                }

                tempShape.oneRight(); // Move back to right side
                return spaceResult;
        }

        private Result checkRight(Result spaceResult, Shape tempShape, Field currField, ArrayList<MoveType> moves) {
                // TODO Auto-generated method stub
                moves.add(MoveType.RIGHT);
                tempShape.oneRight();

                Result tempResult = searchSpace(tempShape, currField, moves, "Right");

                if (tempResult.score > spaceResult.score) {
                        spaceResult = tempResult;
                }

                tempShape.oneLeft();
                return spaceResult;
        }

        public static void main(String[] args) {
                BotParser parser = new BotParser(new BotStarter());
                parser.run();
        }

//        public void write(String line) {
//                try {
//                        FileWriter writer = new FileWriter("starter_out.txt", true);
//                        writer.write(line);
//                        writer.write("\n");
//                        writer.close();
//                } catch (IOException e) {
//                        // TODO Auto-generated catch block
//                        e.printStackTrace();
//                }
//        }

        static class Result {
                ArrayList<MoveType> moves;
                double score;

                public Result(ArrayList<MoveType> moves, double score) {
                        this.score = score;
                        this.moves = moves;
                }
        }
}
