from Bot.Strategies.RandomStrategy import RandomStrategy
from Bot.Strategies.NaiveStrategy import NaiveStrategy
from Bot.Strategies.BestFitStrategy import BestFitStrategy


def create(strategyType, game):
    switcher = {
        "random": RandomStrategy(game),
        "naive": NaiveStrategy(game),
        "bestfit": BestFitStrategy(game)
    }

    strategy = switcher.get(strategyType.lower())

    return Planner(strategy)

class Planner:
    def __init__(self, strategy):
        self._strategy = strategy

    def makeMove(self):
        return self._strategy.choose()